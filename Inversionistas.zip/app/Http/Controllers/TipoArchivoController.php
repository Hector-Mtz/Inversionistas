<?php

namespace App\Http\Controllers;

use App\Models\tipoArchivo;
use Illuminate\Http\Request;

class TipoArchivoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        tipoArchivo::create(
            $request->validate([
                'nombreTipoArchivo' => ['required', 'max:50'],
            ])
        );
        return  redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\tipoArchivo  $tipoArchivo
     * @return \Illuminate\Http\Response
     */
    public function show(tipoArchivo $tipoArchivo)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\tipoArchivo  $tipoArchivo
     * @return \Illuminate\Http\Response
     */
    public function edit(tipoArchivo $tipoArchivo)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\tipoArchivo  $tipoArchivo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, tipoArchivo $tipoArchivo)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\tipoArchivo  $tipoArchivo
     * @return \Illuminate\Http\Response
     */
    public function destroy(tipoArchivo $tipoArchivo)
    {
        //
    }
}
